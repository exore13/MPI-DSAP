#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>

#define maxn 1000
int main(int argc, char **argv)
{
   int myrank,numprocs;
   int i,j,n,ln,indice;
   double x[maxn], y[maxn];
   MPI_Status status;


   MPI_Init(&argc,&argv);
   MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
   MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
     
   if (myrank == 0) {
         printf("Numero de elementos en los vectores originales: \n");
         scanf("%d", &n);
         if (n > maxn) {
             printf("El valor introducido sobrepasa el maximo: %d\n", maxn);
         }
         for (i=1;i<numprocs;i++) 
             MPI_Send( &n, 1, MPI_INT, i, 0, MPI_COMM_WORLD);    
   }
   else
         MPI_Recv ( &n, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, &status); 

   if (n > maxn) {
         MPI_Finalize();
         return 0;
   }

   if (myrank == 0) {
         for (i=0; i<n; i++) {
                 x[i] = i+1;
                 y[i] = (double)1/(i+1);
         }
       
       printf("Soy %d. Antes del send/recv el valor de x es:",myrank);
       for (i=0; i<n; i++) printf("%5.2f ",x[i]);
       printf("\n");
       printf("Soy %d. Antes del send/recv el valor de y es:",myrank);
       for (i=0; i<n; i++) printf("%5.2f ",y[i]);
       printf("\n");

         j=n/numprocs;
         ln = j + n%numprocs;
         indice = ln;
         for (i=1; i<numprocs; i++) {
             MPI_Send( &x[indice], j, MPI_DOUBLE, i, i, MPI_COMM_WORLD);
             MPI_Send( &y[indice], j, MPI_DOUBLE, i, i, MPI_COMM_WORLD);
             indice = indice + j;
         }
   }
   else {
          ln = n/numprocs;
       printf("Soy %d. Antes del send/recv el valor de x es:",myrank);
       for (i=0; i<n; i++) printf("%5.2f ",x[i]);
       printf("\n");
       printf("Soy %d. Antes del send/recv el valor de y es:",myrank);
       for (i=0; i<n; i++) printf("%5.2f ",y[i]);
       printf("\n");

          MPI_Recv ( x, ln, MPI_DOUBLE, 0, myrank, MPI_COMM_WORLD, &status);
          MPI_Recv ( &y[0], ln, MPI_DOUBLE, 0, myrank, MPI_COMM_WORLD, &status);
   }

       printf("Soy %d. Despues del send/recv el valor de x es:",myrank);
       for (i=0; i<n; i++) printf("%5.2f ",x[i]);
       printf("\n");
       printf("Soy %d. Despues del send/recv el valor de y es:",myrank);
       for (i=0; i<n; i++) printf("%5.2f ",y[i]);
       printf("\n");
    MPI_Finalize();
}

