#include <stdio.h>
#include <stdlib.h> // Para usar malloc
/* Programa ejemplo de como definir un array 2d en memoria dinamica
 almacenando los elementos de forma continua */

/* Allocate un puntero a un array 2d */
double **allocate_array(int row_dim, int col_dim)
{
  double **result;
  int i;
  /* Necesitamos ir con cuidado: el array debe ser asignado a un
      trozo contiguo de memoria, para que MPI pueda distribuirlo
      correctamente. */
  result=(double **)malloc(row_dim*sizeof(double *));
  result[0]=(double *)malloc(row_dim*col_dim*sizeof(double));
  for(i=1; i<row_dim; i++)
    result[i]=result[i-1]+col_dim;
  return result;
}

/* Desasignamos un puntero a un array 2d*/
void deallocate_array(double **array, int row_dim) 
{
  int i;
  for(i=1; i<row_dim; i++)
    array[i]=NULL;
  free(array[0]);
  free(array);
}

/* Visualizamos una matrix */ 
void vermatriz(double **matrix, int fil, int col, char nombre[]){

    int i,j;

    printf("%s = \n",nombre);
    for (j=1;j<col;j++){
        printf("%7d ",j);
    }
    printf("\n");
    for (i=0;i<fil;i++){
        printf("%8d:",i);
        for (j=0;j<col;j++){
            printf("%7.3f ",matrix[i][j]);
        }
        printf("\n");
    }
}

int main( int argc, char **argv )
{
  /* Declaraciones */
  double **a;
  int nrow_a, ncol_a;
  int i,j;

    printf("Numero de filas de A:\n");
    scanf("%d",&nrow_a);
    printf("Numero de columnas de A:\n");
    scanf("%d",&ncol_a);

    /* Allocate arrays */
    a = allocate_array(nrow_a, ncol_a);

    /* Initialize arrays */
    for(i=0; i<nrow_a; i++)
      for(j=0;j<ncol_a; j++) 
          a[i][j]=(i+j);
    
    vermatriz(a, nrow_a, ncol_a, "a");
    
    /* Deallocate arrays */
    deallocate_array(a, nrow_a);
}

