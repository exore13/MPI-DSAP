#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define maxm 1000
#define maxn 1000

int main(int argc, char **argv)
{
   void vermatriz(int lda, double a[][lda], int, int, char []);
   void vervector(double a[], int m, char nombre[]);
   double a[maxm][maxn], x[maxn], sol[maxm];
   int i, j;
   int m, n;
   
   printf("Numero de filas (1 - %d): \n",maxm);
   scanf("%d",&m);
   while ((m <= 0) || (m > maxm)) {
      printf("Numero de filas (1 - %d): \n",maxm);
      scanf("%d",&m);
   }
   printf("Numero de columnas (1 - %d): \n",maxn);
   scanf("%d",&n);
   while ((n <= 0) || (n > maxn)) {
      printf("Numero de columnas (1 - %d): \n",maxn);
      scanf("%d",&n);
   }
   for (i=0; i<m; i++){
       for (j=0; j<n; j++){
           a[i][j] =  i+j;
       }
   }
   for (j=0; j<n; j++) x[j]= j;
   if ((m <= 10) && (n <= 10)) {
      vermatriz(maxn, a, m, n, "A");
      printf("\n");
      vervector(x, n, "x");
   }
   for (i=0;i<m;i++){
       sol[i] = 0;
       for (j=0;j<n;j++) {
            sol[i] = sol[i]  + a[i][j]*x[j];
       }
   }    
   vervector(sol, m, "A*x");
} 

void vermatriz(int lda, double a[][lda], int m, int n, char nombre[])
{
 int i,j;
 printf("%4s =",nombre);
 printf("%6d ",0);
 for (j=1;j<n;j++){
     printf("%7d ",j);
 }
 printf("\n");
 for (i=0;i<m;i++){
     printf("%8d:",i);
     for (j=0;j<n;j++){
         printf("%7.3f ",a[i][j]);
     }
     printf("\n");
 }      
}

void vervector(double a[], int m, char nombre[])
{
 int i;
 printf("%6s = ",nombre);
 for (i=0;i<m;i++){
     printf("%7.3f ",a[i]);
     if ((i+1)%5  == 0) printf("\n         ");
 }
 printf("\n"); 
}



