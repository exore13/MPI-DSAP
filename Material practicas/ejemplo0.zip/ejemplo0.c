#include <stdio.h>
#include <mpi.h>

int main (int argc, char **argv)
{
    int pid, npr, A;
    // Inicializamos el entorno MPI
    MPI_Init(&argc, &argv);
    A = 2;
    // Obtenemos el rango de los procesos
    MPI_Comm_rank(MPI_COMM_WORLD, &pid);
    // Obtenemos el numero de procesos
    MPI_Comm_size(MPI_COMM_WORLD, &npr);
    A = A + 1;
    // Imprimimos un mensaje
    printf("Proceso %d de %d activado. A = %d \n", pid, npr, A);
           
    // Finalizamos el entorno MPI.
    MPI_Finalize();
}
