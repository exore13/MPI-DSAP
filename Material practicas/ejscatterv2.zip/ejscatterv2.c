#include <stdio.h>
#include <math.h>
#include <stdlib.h> // Para usar malloc, para limpiar pantalla
#include <mpi.h>

#define maxm 1000
#define maxn 1000
#define maxnumprocs 8

/* Desasignamos un puntero a un array 2d*/
void deallocate_array(double **array, int row_dim) 
{
  int i;
  for(i=1; i<row_dim; i++)
    array[i]=NULL;
  free(array[0]);
  free(array);
}

/* Asignamos un puntero a un array 2d*/
double **allocate_array(int row_dim, int col_dim)
{
  double **result;
  int i;
  /* Necesitamos ir con cuidado: el array debe ser asignado a un
      trozo contiguo de memoria, para que MPI pueda distribuirlo
      correctamente. */
  result=(double **)malloc(row_dim*sizeof(double *));
  result[0]=(double *)malloc(row_dim*col_dim*sizeof(double));
  for(i=1; i<row_dim; i++)
    result[i]=result[i-1]+col_dim;
  return result;
}

void vermatriz(double **a, int m, int n, char nombre[])
{
 int i,j;
 printf("%4s =",nombre);
 printf("%6d ",0);
 for (j=1;j<n;j++){
     printf("%7d ",j);
 }
 printf("\n");
 for (i=0;i<m;i++){
     printf("%8d:",i);
     for (j=0;j<n;j++){
         printf("%7.3f ",a[i][j]);
     }
     printf("\n");
 }      
}

void inicializarEstructuras(int m, int n, double** a) {

    int i, j;
    for (i=0; i<m; i++){
       for (j=0; j<n; j++){
           a[i][j] =  i+j;
       }
    }
}

int main(int argc, char **argv)
{
    int m = 0, n = 0;
   
    int pid, numprocs, i, j, lm, root, resto, slice;
  /**********************************************************************************************************************
   * A = Matriz inicial del proceso padre.                                                                              *
   * D = Matriz parcial de cada uno de los nodos. Se troceará la matriz A y cada hijo recibirá un trozo guardandolo en D*
   **********************************************************************************************************************/
    double **A, **D;
    int *a_chunk_sizes;
    int *a_despla;
 
    system("clear"); // Limpiar pantalla

    root = 0;

    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &pid);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    
    if(numprocs > maxnumprocs && pid == root) {
        printf("Error, el numero maximo de procesos es 8\n");
        return 1;
    }

    a_chunk_sizes=(int *)malloc(numprocs*sizeof(int));
    a_despla=(int *)malloc(numprocs*sizeof(int));
  
    // El padre pide por pantalla el tamaño de la matriz
    if(pid == root) {
        while ((m <= 0) || (m > maxm)) {
          printf("Numero de filas (1 - %d): \n",maxm);
          scanf("%d",&m);
        }

        while ((n <= 0) || (n > maxn)) {
          printf("Numero de columnas (1 - %d): \n",maxn);
          scanf("%d",&n);
        }
    }

    // Se envian los tamaños de la matriz a todos los hijos
    MPI_Bcast(&m, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&n, 1, MPI_INT, 0, MPI_COMM_WORLD);

    A = allocate_array(m, n);

    // Se inicializa la matriz
    if(pid == root) {

        inicializarEstructuras(m, n, A);
        
        if ((m <= 10) && (n <= 10)) {
            vermatriz(A, m, n, "A");
            printf("\n");
        }
    }

    // Se calculan los trozos correspondientes a cada nodo dividiendo la carga
    // equitativamente. Si la division no es entera, el padre se queda con el resto
    // de la carga
    slice = m/numprocs;
    resto = m % numprocs;

    /*******************************************************************************
     * Se calculan para cada nodo el numero de elementos de cada trozo,            *
     * y el correspondiente desplazamiento que tiene que tener en cuenta la        *
     * operacion Scatterv.                                                         *
     *******************************************************************************/
    for(i=1; i < numprocs; i++) {
        a_chunk_sizes[i] = slice*n;
        a_despla[i] = resto*n + i*slice*n;
      }
    
    a_chunk_sizes[0]=(slice+resto)*n;
    a_despla[0] = 0;

    if(pid != 0) {
    	  resto = 0;
    }

    D = allocate_array(slice + resto, n);

    // Se realiza el troceo de la matriz A. Cada nodo recibe su trozo correspondiente
    // en la matriz D.
    MPI_Scatterv(&A[0][0],a_chunk_sizes,&a_despla[0],MPI_DOUBLE,
                 &D[0][0],a_chunk_sizes[pid],MPI_DOUBLE,root,MPI_COMM_WORLD);

    lm = a_chunk_sizes[pid]/n;
 	  
    MPI_Barrier(MPI_COMM_WORLD);

    printf("Soy el proceso %d.\n", pid);
    vermatriz(D,lm,n,"A");
    printf("\n");

    deallocate_array(A, m);

    if(pid == root) {
        printf("\n");
		    deallocate_array(D, slice + resto);
    }
    else{
	      deallocate_array(D, slice);
    }

   MPI_Finalize();
} 





