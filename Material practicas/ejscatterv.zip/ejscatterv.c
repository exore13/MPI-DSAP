#include <stdio.h>
#include <mpi.h>
#include <stdlib.h>

#define m 7
#define n 10

int main(int argc, char **argv)
{
    void vermatriz(int max, double a[][max], int , int , char []);

    int myrank, numprocs, i, j, lm, root, resto, slice;
    double A[m][n], D[m][n];
    int *a_chunk_sizes;
    int *a_despla;


    MPI_Init(&argc,&argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &myrank);
    MPI_Comm_size(MPI_COMM_WORLD, &numprocs);
    
    a_chunk_sizes=(int *)malloc(numprocs*sizeof(int));
    a_despla=(int *)malloc(numprocs*sizeof(int));


    root = 0;
 
    if (myrank == root)
    {
       for (i=0; i<m; i++)
          for (j=0; j<n; j++)
             A[i][j] = i-j;
       vermatriz(n,A,m,n,"A");
    }
    MPI_Barrier(MPI_COMM_WORLD);
    
    slice = m/numprocs;
    resto = m % numprocs;
    
    for(i=1; i<=numprocs-1; i++) {
        a_chunk_sizes[i]=slice*n;
        a_despla[i] = resto*n + i*slice*n;
    }
    
    a_chunk_sizes[0]=(slice+resto)*n;
    a_despla[0] = 0;
    
    printf("Proceso %d, a_chunk_sizes %d , a_despla %d \n", myrank, a_chunk_sizes[myrank], a_despla[myrank]);

    MPI_Scatterv(&A[0][0],a_chunk_sizes,&a_despla[0],MPI_DOUBLE,
                 &D[0][0],a_chunk_sizes[myrank],MPI_DOUBLE,root,MPI_COMM_WORLD);
    
    lm = a_chunk_sizes[myrank]/n;
    printf("\n");
    vermatriz(n,D,lm,n,"D");
    printf("\n");
 
    MPI_Barrier(MPI_COMM_WORLD);
    
    MPI_Finalize();
}

void vermatriz(int max, double a[][max], int fil, int col, char nombre[]){
int i,j;
printf("%5s=",nombre);
printf("%6d ",0);
for (j=1;j<col;j++){
   printf("%7d ",j);
}
printf("\n");
for (i=0;i<fil;i++){
   printf("%8d:",i);
   for (j=0;j<col;j++){
      printf("%7.3f ",a[i][j]);
   }
   printf("\n");
}
}

